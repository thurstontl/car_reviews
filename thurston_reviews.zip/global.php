<?php $connection = mysqli_connect("localhost","root","","car_reviews");
?>